# 🎬 Actor Simulator Game (Offline)

This is a basic Unity 2D mobile game project where you simulate the career of an aspiring actor. Train skills, attend auditions, earn fame, and climb your way to stardom — all offline!

## 🚀 Features
- Skill Training: Acting, Dancing, Action
- Audition mini-system
- Fame and Money tracking
- Offline and mobile-ready

## 📂 Folder Structure
- `Assets/Scripts` – Game logic
- `Assets/Scenes` – You can create Unity scenes here
- `README.md` – Project overview

## 🛠 Requirements
- Unity 2021 or later
- Android Build Support (if targeting mobile)

## 📱 Build & Run
1. Open project in Unity.
2. Add your UI via Unity Editor.
3. Attach `GameManager.cs` to a GameObject.
4. Connect UI buttons to `TrainActing`, `TrainDancing`, and `TryAudition`.
5. Export to Android via Build Settings.

---

Made with 💙 for learning and fun.