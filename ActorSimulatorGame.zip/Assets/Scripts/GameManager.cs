using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Character player;

    void Start()
    {
        player = new Character();
        player.actorName = "You";
        UpdateStatsUI();
    }

    public void TrainActing()
    {
        player.TrainSkill("acting");
        UpdateStatsUI();
    }

    public void TrainDancing()
    {
        player.TrainSkill("dancing");
        UpdateStatsUI();
    }

    public void TryAudition()
    {
        Audition audition = new Audition();
        audition.requiredActing = 60;

        if (audition.AttendAudition(player))
        {
            Debug.Log("🎉 You got the role!");
            player.fame += 20;
            player.money += 100;
        }
        else
        {
            Debug.Log("❌ You failed the audition.");
            player.fame -= 5;
        }
        UpdateStatsUI();
    }

    void UpdateStatsUI()
    {
        Debug.Log($"Fame: {player.fame} | Money: {player.money}");
    }
}