[System.Serializable]
public class Character
{
    public string actorName;
    public int fame = 0;
    public int money = 100;
    public int acting = 50;
    public int dancing = 40;
    public int action = 30;

    public void TrainSkill(string skill)
    {
        switch (skill)
        {
            case "acting": acting += 5; break;
            case "dancing": dancing += 5; break;
            case "action": action += 5; break;
        }
        money -= 10;
    }
}