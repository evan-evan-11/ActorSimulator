public class Audition
{
    public int requiredActing;

    public bool AttendAudition(Character actor)
    {
        return actor.acting >= requiredActing;
    }
}